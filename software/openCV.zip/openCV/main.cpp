#include <opencv2/highgui.hpp>
#include <iostream>
#include <vector>



using namespace cv;
using namespace std;

int main()
{
    IplImage * image  = cvLoadImage("F:\\SystemFile\\Documents\\openCV\\1.jpg");
    cvNamedWindow("example",CV_WINDOW_AUTOSIZE);
    cvShowImage("example",image);
    cvWaitKey(0);
    cvReleaseImage(&image);
    cvDestroyWindow("example");
    cout<<"hellp"<<endl;

    vector<int> iVec;
    iVec.push_back(1);

    return 0;
}
